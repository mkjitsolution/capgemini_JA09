package p1;

public class StudentArrayDemo {

	public static void main(String[] args) {
		
		Student s;
		s = new Student();
		int x;
		x = 10;
		
		// step 1
		Student students[] = new Student[5];
		
		Student s1;
		Student s2;
		Student s3;
		Student s4;
		Student s5;
		
		
		// step 2
		/*
		 * for (Student student : students) { student = new Student();
		 * student.setStudentInfo("", 11, 454); }
		 * 
		 */
		
		
	}
}
