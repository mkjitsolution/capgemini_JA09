package p1;

public class ArrayDemo {
	
	public static void main(String[] args) {
		
		
		int arr[] = new int[5];
		
		String arr2[] = new String[3];
		arr2[0] = "mike";
		arr2[1] = "mikevghv";
		arr2[2] = "mikfdgerdge";
		
		
		for (String name : arr2) {
			System.out.println(name);
		}
		
		
	}

}
