package p1;

public class StudentMainClass {
	
	public static void main(String[] args) {

		Student obj = new Student();  // creation of Object
	
		/*
		      NOTE: - Error Because Data Members are private
		      
		obj.id = 101;     // Accessing the Data 
		obj.name = "ramesh";
		obj.marks = 55;
		
		System.out.println(obj);
		
		System.out.println("Id "+obj.id);
		System.out.println("name "+obj.name);
		System.out.println("Marks "+obj.marks);
		*/
		
		/*
		 * obj.provideName("mike"); obj.setStudentInfo("mike",101, 22);
		 * obj.displayStudentInfo();
		 * 
		 * obj.giveExam(4); obj.displayStudentInfo();
		 * 
		 * 
		 * 
		 * Student abc = new Student();
		 */
		
		
		
		
		
		
		
		
		
		
	}
}
